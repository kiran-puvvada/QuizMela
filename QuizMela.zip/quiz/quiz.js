
  // JavaScript code here
const questions = [
    {
        question: "What is the capital of France?",
        options: ["Paris", "London", "Berlin", "Rome"],
        answer: "Paris"
    },
    {
        question: "What is the largest planet in our solar system?",
        options: ["Earth", "Mars", "Jupiter", "Venus"],
        answer: "Jupiter"
    },
    {
        question: "Which gas do plants absorb from the atmosphere?",
        options: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"],
        answer: "Carbon Dioxide"
    },
    {
        question: "What is the chemical symbol for gold?",
        options: ["Ag", "Au", "Hg", "Pt"],
        answer: "Au"
    },
    {
        question: "Which planet is known as the Red Planet?",
        options: ["Mars", "Venus", "Jupiter", "Saturn"],
        answer: "Mars"
    }
];

let currentQuestion = 0;
let score = 0;
const timePerQuestion = 10;
let timeLeft = timePerQuestion;
let timerInterval;

const questionTextElement = document.getElementById('question-text');
const optionsListElement = document.getElementById('options-list');
const submitButton = document.getElementById('submit-btn');
const nextButton = document.getElementById('next-btn');
const restartButton = document.getElementById('restart-btn');
const resultElement = document.getElementById('result');
const timeLeftElement = document.getElementById('time-left');
const timerContainer = document.getElementById('timer-container'); // Get the timer container

function loadQuestion() {
    const currentQuiz = questions[currentQuestion];
    questionTextElement.textContent = currentQuiz.question;
    optionsListElement.innerHTML = '';

    currentQuiz.options.forEach((option, index) => {
        const li = document.createElement('li');
        const input = document.createElement('input');
        input.type = 'radio';
        input.name = 'q1'; // Use a dynamic name for multiple questions
        input.value = option;
        li.appendChild(input);
        li.appendChild(document.createTextNode(option));
        optionsListElement.appendChild(li);
    });

    submitButton.style.display = 'block';
    nextButton.style.display = 'none';
    restartButton.style.display = 'none';
    resetTimer();
    startTimer(); // Start the timer when a new question is loaded
}

function checkAnswer() {
    const selectedOption = document.querySelector('input[type="radio"]:checked');
    if (!selectedOption) return;

    const answer = selectedOption.value;
    const currentQuiz = questions[currentQuestion];
    if (answer === currentQuiz.answer) {
        score++;
    }

    submitButton.style.display = 'none';
    nextButton.style.display = 'block';
    restartButton.style.display = 'none';
    clearInterval(timerInterval);
}

function showResult() {
    resultElement.textContent = `You scored ${score} out of ${questions.length}`;
    timeLeftElement.textContent = '';
    timerContainer.style.display = 'none';
   
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion < questions.length) {
        loadQuestion();
    } else {
        showResult();
        submitButton.style.display = 'none';
        nextButton.style.display = 'none';
        restartButton.style.display = 'block';
    }
}

function startTimer() {
    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        if (timeLeft > 0) {
            timeLeft--;
            timeLeftElement.textContent = timeLeft;
        } else {
            clearInterval(timerInterval);
            nextQuestion();
        }
    }, 1000);
}

function resetTimer() {
    clearInterval(timerInterval);
    timeLeft = timePerQuestion;
    timeLeftElement.textContent = timeLeft;
}

loadQuestion();

submitButton.addEventListener('click', () => {
    checkAnswer();
    clearInterval(timerInterval);
});
nextButton.addEventListener('click', nextQuestion);
restartButton.addEventListener('click', () => {
    currentQuestion = 0;
    score = 0;
    resultElement.textContent = '';
    loadQuestion();
});
  